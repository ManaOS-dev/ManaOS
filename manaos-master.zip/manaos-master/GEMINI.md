See AGENTS.md for all coding rules. Follow them strictly.
