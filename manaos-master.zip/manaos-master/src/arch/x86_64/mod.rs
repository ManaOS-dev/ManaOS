pub mod global_descriptor_table;
pub mod interrupt_descriptor_table;

/// x86_64 specific implementations.
/// x86_64 specific initialization.
pub fn init() {
    global_descriptor_table::init();
    interrupt_descriptor_table::initialize();
    // SAFETY: The interrupt controllers are initialized while interrupts are
    // disabled during early architecture setup.
    unsafe {
        let mut interrupt_controllers = interrupt_descriptor_table::INTERRUPT_CONTROLLERS.lock();
        interrupt_controllers.initialize();

        // 0xf8: 11111000 (Timer, Keyboard, Cascade enabled)
        // 0xef: 11101111 (Mouse enabled)
        interrupt_controllers.write_masks(0xf8, 0xef);
    }

    // Initialize PIT (Programmable Interval Timer)
    init_pit(1000);

    // Initialize Drivers (while interrupts are still disabled)
    crate::kernel::driver::input::mouse::init();
    crate::serial_println!("[ok   ] Mouse initialized.");

    x86_64::instructions::interrupts::enable();
}

/// Set PIT frequency to target_hz
fn init_pit(target_hz: u32) {
    use x86_64::instructions::port::Port;
    let divider = 1193182 / target_hz;
    let mut command_port = Port::<u8>::new(0x43);
    let mut data_port = Port::<u8>::new(0x40);

    // SAFETY: Ports 0x43 and 0x40 are the interval timer command and channel 0
    // data ports, used during single-threaded architecture initialization.
    unsafe {
        command_port.write(0x36); // Square wave, Lo/Hi byte
        data_port.write((divider & 0xFF) as u8);
        data_port.write(((divider >> 8) & 0xFF) as u8);
    }
}

pub fn hlt_loop() -> ! {
    loop {
        x86_64::instructions::hlt();
    }
}
