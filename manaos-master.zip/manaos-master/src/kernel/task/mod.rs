//! # kernel::task
//!
//! ## Owns
//! - Task metadata and task context module boundaries
//!
//! ## Does NOT own
//! - Architecture-specific context switching details (-> arch)
//!
//! ## Public API
//! - [`Task`] - Basic task metadata

pub mod context;

/// Basic task metadata used by the scheduler.
#[allow(dead_code)]
pub struct Task {
    id: u64,
    priority: u8,
}

impl Task {
    /// Create a new task with the given identifier and priority.
    #[allow(dead_code)]
    pub fn new(id: u64, priority: u8) -> Self {
        Self { id, priority }
    }
}
