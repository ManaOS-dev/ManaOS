//! Task context storage.
